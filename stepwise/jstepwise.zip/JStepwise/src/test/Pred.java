package test;

import stepwise.Attr;
import stepwise.BacktrackException;
import stepwise.Node;

public abstract class Pred extends Node<Pred,Info,BacktrackException> {
	PredInh _inhs;
	PredSyn _syns;

	public Pred() {
		_inhs = null;
		_syns = new PredSyn() {
			private final Attr<Boolean> _value = new Attr<Boolean>();

			@Override
			public Attr<Boolean> attrValue() {
				return _value;
			}
		};
	}
	
	public void setContext(final PredInh inhs) {
		_inhs = inhs;
	}
	
	public PredSyn getSyns() {
		return _syns;
	}
	
	public PredInh getInhs() {
		return _inhs;
	}
}
