package test;

public interface Info {

}
