package test;

import stepwise.BacktrackException;
import stepwise.Report;
import stepwise.Stepwise;
import stepwise.BinMerge;

public class ChooseOr extends BinMerge<Pred,Info,BacktrackException> {
	public ChooseOr(Stepwise<Pred,Info,BacktrackException> left, Stepwise<Pred,Info,BacktrackException> right) {
		super(left,right);
	}

	@Override
	protected void runStep() {
		Report<Pred, Info, BacktrackException> r1 = _left.nextStep();
		Report<Pred, Info, BacktrackException> r2 = _right.nextStep();
		
		System.out.println("runStep()");
		
		if (r1.isDone()) {
			System.out.println("commit left (r1 done)");
			commit(_left.lazyEval().getSyns().attrValue().getValue() ? _left : _right);
		} else if (r2.isDone()) {
			System.out.println("commit right (r2 done)");
			commit(_right.lazyEval().getSyns().attrValue().getValue() ? _right : _left);
		} else if (r1.hasFailed()) {
			System.out.println("commit right (r1 failed)");
			commit(_right);
		} else if (r2.hasFailed()) {
			System.out.println("commit left (r2 failed)");
			commit(_left);
		} else {
			System.out.println("nothing; both stepped");
			emit(new InfoWork());
		}
	}
}
