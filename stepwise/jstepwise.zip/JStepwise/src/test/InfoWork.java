package test;

public final class InfoWork implements Info {
	public InfoWork() {
	}
}
