package test;

import stepwise.BacktrackException;
import stepwise.Parents;
import stepwise.Report;

public final class PredVar extends Pred {	
	private String _name;
	private int _state;
	
	private Runnable _rule1;
	
	public PredVar(final String name) {
		_name = name;
		_state = 0;
		
		_rule1 = new Runnable() {
			public void run() {
				boolean b = _inhs.attrEnv().getValue().get(_name);
				_syns.attrValue().setValue(b);
			}
		};
	}

	@Override
	public Report<Pred,Info,BacktrackException> visit() {
		switch(_state) {
		case 0:
			_state = 1;  // next state
			return new Report<Pred, Info, BacktrackException>(new InfoWork(), new Parents<Pred, Info, BacktrackException>(this));
		case 1:
			_rule1.run();
			_state = -1; // done
			return null;
		}
		return null; // nothing else to be done
	}

	@Override
	protected void initialize() {
		_syns.attrValue().setRule(_rule1);
	}
}
