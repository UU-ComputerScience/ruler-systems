package test;

import java.util.HashMap;

import stepwise.Attr;
import stepwise.BacktrackException;
import stepwise.Stepwise;

public final class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// build tree
		Pred p1 = new PredVar("x");
		Pred p2 = new PredVar("y");
		Pred p3 = new PredOr(p1,p2);
		
		// set inherited attrs of the root
		PredInh inhs = new PredInh() {
			private Attr<HashMap<String, Boolean>> env = new Attr<HashMap<String, Boolean>>();

			@Override
			public Attr<HashMap<String, Boolean>> attrEnv() {
				return env;
			}
		};
		inhs.attrEnv().setValue(new HashMap<String,Boolean>());
		inhs.attrEnv().getValue().put("x", false);
		inhs.attrEnv().getValue().put("y", true);
		p3.setContext(inhs);

		// start on-demand evaluation
		Stepwise<Pred, Info, BacktrackException> outcome = p3.beginVisits();
		boolean result = outcome.lazyEval().getSyns().attrValue().getValue();
		System.out.println("result: " + result);
	}
}
