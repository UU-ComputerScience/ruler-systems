package test;

import stepwise.Attr;

public interface PredSyn {
	public Attr<Boolean> attrValue();
}
