package test;

import java.util.HashMap;

import stepwise.Attr;
import stepwise.BacktrackException;
import stepwise.Report;
import stepwise.Stepwise;

public final class PredLet extends Pred {
	private String _name;
	private Pred _expr;
	private Pred _body;
	private Stepwise<Pred, Info, BacktrackException> _exprOutcome;
	private Stepwise<Pred, Info, BacktrackException> _bodyOutcome;
	private int _state;
	private Runnable _rule1;
	private Runnable _rule2;
	private Runnable _rule3;
	
	
	@SuppressWarnings("unchecked")
	public PredLet(final String name, final Pred expr, final Pred body) {
		_name = name;
		_expr = expr;
		_body = body;
		_exprOutcome = null;
		_bodyOutcome = null;
		_state = 0;
		
		_rule1 = new Runnable() {
			public void run() {
				HashMap<String, Boolean> env = _inhs.attrEnv().getValue();
				_expr.getInhs().attrEnv().setValue(env);
			}
		};
		
		_rule2 = new Runnable() {
			public void run() {
				boolean val = getExpr().lazyEval().getSyns().attrValue().getValue();
				HashMap<String, Boolean> env = (HashMap<String, Boolean>) _inhs.attrEnv().getValue().clone();
				env.put(_name, val);
				_body.getInhs().attrEnv().setValue(env);
			}
		};
		
		_rule3 = new Runnable() {
			public void run() {
				boolean val = getBody().lazyEval().getSyns().attrValue().getValue();
				_syns.attrValue().setValue(val);
			}
		};
	}

	@Override
	public Report<Pred, Info, BacktrackException> visit() {
		switch (_state) {
		case 0:
			
			_exprOutcome = _expr.beginVisits();
			_state = 1;
			return new Report<Pred, Info, BacktrackException>(_exprOutcome);
		case 1:
			_state = 2;
		}
		
		return null;
	}

	@Override
	protected void initialize() {
		PredInh exprInh = new PredInh() {
			private Attr<HashMap<String, Boolean>> env = new Attr<HashMap<String, Boolean>>();

			@Override
			public Attr<HashMap<String, Boolean>> attrEnv() {
				return env;
			}
		};
		exprInh.attrEnv().setRule(_rule1);
		_expr.setContext(exprInh);
		
		PredInh bodyInh = new PredInh() {
			private Attr<HashMap<String, Boolean>> env = new Attr<HashMap<String, Boolean>>();

			@Override
			public Attr<HashMap<String, Boolean>> attrEnv() {
				return env;
			}
		};
		bodyInh.attrEnv().setRule(_rule2);
		_body.setContext(bodyInh);
		
		_syns.attrValue().setRule(_rule3);
	}
	
	private Stepwise<Pred, Info, BacktrackException> getExpr() {
		if (_exprOutcome == null)
			_exprOutcome = _expr.beginVisits();
		
		return _exprOutcome;
	}

	private Stepwise<Pred, Info, BacktrackException> getBody() {
		if (_bodyOutcome == null)
			_bodyOutcome = _body.beginVisits();
		
		return _bodyOutcome;
	}
}
