package test;

import java.util.HashMap;
import stepwise.Attr;

public interface PredInh {
	Attr<HashMap<String,Boolean>> attrEnv();
}
