package test;

import java.util.HashMap;

import stepwise.Attr;
import stepwise.BacktrackException;
import stepwise.Report;
import stepwise.Stepwise;

public final class PredOr extends Pred {
	private Pred _left;
	private Pred _right;
	private Stepwise<Pred, Info, BacktrackException> _res;
	private int _state;
	
	private Runnable _rule1;
	private Runnable _rule2;
	private Runnable _rule3;
	
	public PredOr(final Pred left, final Pred right) {
		_left = left;
		_right = right;
		_res   = null;
		_state = 0;
		
		_rule1 = new Runnable() {
			public void run() {
				_left.getInhs().attrEnv().setValue(_inhs.attrEnv().getValue());
			}
		};
		
		_rule2 = new Runnable() {
			public void run() {
				_right.getInhs().attrEnv().setValue(_inhs.attrEnv().getValue());
			}
		};
		
		_rule3 = new Runnable() {
			public void run() {
				boolean b = getRes().lazyEval().getSyns().attrValue().getValue();
				_syns.attrValue().setValue(b);
			}
		};
	}

	@Override
	public Report<Pred, Info, BacktrackException> visit() {
		switch(_state) {
		case 0:
			_state = 1;
			_rule1.run();
			_rule2.run();
			return new Report<Pred, Info, BacktrackException>(getRes());
		case 1:
			_rule3.run();
			_state = -1;
			return null;
		}
		return null;
	}

	@Override
	protected void initialize() {
		PredInh leftInhs = new PredInh() {
			private Attr<HashMap<String, Boolean>> env = new Attr<HashMap<String, Boolean>>();

			@Override
			public Attr<HashMap<String, Boolean>> attrEnv() {
				return env;
			}
		};
		leftInhs.attrEnv().setRule(_rule1);
		_left.setContext(leftInhs);
		
		PredInh rightInhs = new PredInh() {
			private Attr<HashMap<String, Boolean>> env = new Attr<HashMap<String, Boolean>>();

			@Override
			public Attr<HashMap<String, Boolean>> attrEnv() {
				return env;
			}
		};
		rightInhs.attrEnv().setRule(_rule2);
		_right.setContext(rightInhs);
		
		_syns.attrValue().setRule(_rule3);
	}
	
	private Stepwise<Pred, Info, BacktrackException> getRes() {
		if (_res == null)
			_res = new ChooseOr(_left.beginVisits(),_right.beginVisits());

		return _res;
	}
}
