package stepwise;

public final class Report<X,I,E> {
	private E _failure;
	private Stepwise<X,I,E> _next;
	private I _info;

	public Report(E failure) {
		_failure = failure;
		_next = null;
		_info = null;
	}

	public Report(I info, Stepwise<X,I,E> next) {
		_failure = null;
		_next = next;
		_info = info;
	}
	
	public Report(Stepwise<X,I,E> next) {
		_failure = null;
		_next = next;
		_info = null;
	}
	
	public boolean isDone() {
		return _info == null && _failure == null;
	}
	
	public boolean hasFailed() {
		return _failure != null;
	}
	
	public boolean inProgress() {
		return _info != null;
	}

	public E getFailure() {
		return _failure;
	}

	public Stepwise<X,I,E> getNext() {
		return _next;
	}

	public I getInfo() {
		return _info;
	}
}
