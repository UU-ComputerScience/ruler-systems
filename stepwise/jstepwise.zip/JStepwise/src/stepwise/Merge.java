package stepwise;

import java.util.LinkedList;
import java.util.Queue;

public abstract class Merge<X,I,E> implements Stepwise<X, I, E> {
	private Queue<Action<X,I,E>> _actions;
	
	public Merge() {
		_actions = new LinkedList<Action<X,I,E>>();
	}	
	
	// keep running until committed
	// throws away potential info messages
	@Override
	public X lazyEval() {
		while(true) {
			Action<X,I,E> action = _actions.poll();
			if (action != null) {
				if (action instanceof ActionAbort)
					throw new BacktrackException("lazyEval() on failed computation");
				if (action instanceof ActionCommit) {
					Stepwise<X,I,E> choice = ((ActionCommit<X, I, E>) action).getChoice();
					return choice.lazyEval();
				}
			}

			if (action == null)
				runStep();
		}
	}
	
	@Override
	public Report<X,I,E> nextStep() {
		Action<X,I,E> action = null;
		while ((action = _actions.poll()) == null) {
			runStep();
		}
		
		if (action instanceof ActionAbort) {
			E failure = ((ActionAbort<X,I,E>) action).getFailure();
			return new Report<X,I,E>(failure);
		} else if (action instanceof ActionEmit) {
			I info = ((ActionEmit<X,I,E>) action).getInfo();
			return new Report<X,I,E>(info, this);
		} else {
			Stepwise<X,I,E> choice = ((ActionCommit<X,I,E>) action).getChoice();
			return new Report<X,I,E>(choice);
		}
	}
	
	abstract protected void runStep();

	protected void emit(final I info) {
		_actions.add(new ActionEmit<X,I,E>(info));
	}

	protected void commit(final Stepwise<X,I,E> choice) {
		_actions.add(new ActionCommit<X, I, E>(choice));
	}

	protected void abort(final E failure) {
		_actions.add(new ActionAbort<X,I,E>(failure));
	}
	
	private static interface Action<X,I,E> {
	}
	
	private static class ActionAbort<X,I,E> implements Action<X,I,E> {
		private E _failure;
		
		public ActionAbort(final E failure) {
			_failure = failure;
		}
		
		public E getFailure() {
			return _failure;
		}
	}
	
	private static class ActionEmit<X,I,E> implements Action<X,I,E> {
		private I _info;
		
		public ActionEmit(final I info) {
			_info = info;
		}
		
		public I getInfo() {
			return _info;
		}
	}
	
	private static class ActionCommit<X,I,E> implements Action<X,I,E> {
		private Stepwise<X,I,E> _choice;
		
		public ActionCommit(final Stepwise<X,I,E> choice) {
			_choice = choice;
		}
		
		public Stepwise<X,I,E> getChoice() {
			return _choice;
		}
	}
}
