package stepwise;

public interface Stepwise<X,I,E> {
	X lazyEval();
	Report<X,I,E> nextStep();
}
