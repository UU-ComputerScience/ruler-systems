package stepwise;

import java.util.LinkedList;

// the last element of the parents list is the actual node (and of the right type).
public final class Parents<X,I,E> implements Stepwise<X,I,E> {
	private Node<X,I,E> _root;
	private LinkedList<Stepwise<?,?,?>> _stack;
	
	public Parents(final Node<X,I,E> node) {
		_stack = new LinkedList<Stepwise<?,?,?>>();
		_root = node;
	}

	@SuppressWarnings("unchecked")
	@Override
	public X lazyEval() {
		_stack.clear();
		return (X) _root;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Report<X,I,E> nextStep() {
		while(true) {
			// hunt for a report
			Report<?,I,E> rep;
			Stepwise<?,?,?> head = _stack.poll();
			if (head == null) {
				// proceed with evaluation of _root
				rep = _root.visit();
				if (rep == null) // visit returns null, so we are done!
					return new Report<X,I,E>(this);
			} else if (head instanceof Parents) {  // merge stacks
				Parents<?,?,?> other = (Parents<?,?,?>) head;
				_stack.addAll(0, other._stack);
				continue; // repeat
			} else { // evaluate at the head
				rep = (Report<?,I,E>) head.nextStep();
			}

			if (rep.hasFailed()) {
				return new Report<X,I,E>(rep.getFailure());
			} else if (rep.isDone()) {
				continue; // done with the head, next!
			}
			
			// head returned an info message
			if (head != null)  // push the head back on
				_stack.addFirst(head);
			
			return new Report<X,I,E>(rep.getInfo(), this);
		}
	}
}
