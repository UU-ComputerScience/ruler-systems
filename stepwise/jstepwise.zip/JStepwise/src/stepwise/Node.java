package stepwise;

public abstract class Node<X,I,E> {
	public Node() {
	}
	
	protected abstract void initialize();
	
	public Stepwise<X,I,E> beginVisits() {
		initialize();
		return new Parents<X,I,E>(this);
	}
	
	abstract public Report<X,I,E> visit();
}
