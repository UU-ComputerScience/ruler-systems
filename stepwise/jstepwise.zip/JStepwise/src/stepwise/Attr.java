package stepwise;

public final class Attr<T> {
	private T _value;
	private Runnable _rule;
	
	public Attr() {
		_value = null;
		_rule = null;
	}

	public T getValue() {
		if (_value == null)
			_rule.run();
		
		return _value;
	}
	
	public void setValue(final T value) {
		_value = value;
	}
	
	public void setRule(final Runnable rule) {
		_rule = rule;
	}
}
